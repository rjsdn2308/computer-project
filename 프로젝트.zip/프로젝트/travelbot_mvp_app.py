# Minimal Flask MVP for LLM-based Travel Route Bot
# ------------------------------------------------
#  기능
# - /plan (POST): 사용자 선호를 받아 1일~N일 일정 생성
# - Rule-based 초안 + (선택) LLM 리라이트
# - 도시/관심사/동행/예산/도보제약 반영 (간단 가중치)
# - .env의 OPENAI_API_KEY 사용 (없으면 규칙기반만)
# ------------------------------------------------

import os
import json
from datetime import datetime
from typing import List, Dict, Any
from dataclasses import dataclass, asdict

from flask import Flask, request, jsonify
from flask_cors import CORS

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

# (선택) OpenAI 클라이언트 – 키 없으면 스킵
USE_LLM = False
try:
    from openai import OpenAI
    if os.getenv("OPENAI_API_KEY"):
        client = OpenAI()
        USE_LLM = True
except Exception:
    USE_LLM = False

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# ----------------------
# 샘플 POI 데이터 (실서비스는 DB/VectorDB/RAG로 대체)
# ----------------------
POIS = [
    # 오사카
    {"city":"osaka","name":"도톤보리","tags":["야경","먹거리","쇼핑"],"avg_stay":90,"walk_min":10,"price":"$","notes":"글리코상 앞 포토스팟"},
    {"city":"osaka","name":"오사카성 공원","tags":["역사","자연"],"avg_stay":120,"walk_min":20,"price":"$","notes":"벚꽃 시즌 인기"},
    {"city":"osaka","name":"우메다 스카이빌딩 공중정원","tags":["야경","전망"],"avg_stay":80,"walk_min":15,"price":"$$","notes":"전망대 입장료 유"},
    {"city":"osaka","name":"가이유칸 수족관","tags":["가족","실내","동물"],"avg_stay":150,"walk_min":18,"price":"$$$","notes":"아이동반 인기"},
    {"city":"osaka","name":"호젠지 요코초","tags":["레트로","먹거리","사진"],"avg_stay":60,"walk_min":8,"price":"$$","notes":"밤 분위기 좋음"},
    # 서울
    {"city":"seoul","name":"북촌 한옥마을","tags":["전통","사진","산책"],"avg_stay":90,"walk_min":15,"price":"$","notes":"한복체험 연계 가능"},
    {"city":"seoul","name":"DDP","tags":["현대건축","전시","사진"],"avg_stay":70,"walk_min":12,"price":"$","notes":"전시 변동"},
    {"city":"seoul","name":"남산서울타워","tags":["전망","야경"],"avg_stay":80,"walk_min":20,"price":"$$","notes":"케이블카 옵션"},
    {"city":"seoul","name":"광장시장","tags":["먹거리","재래시장"],"avg_stay":60,"walk_min":10,"price":"$","notes":"빈대떡·마약김밥"},
]

SLOTS = ["Morning","Lunch","Afternoon","Dinner","Night"]

@dataclass
class UserPref:
    city: str
    days: int
    interests: List[str]
    with_kids: bool = False
    budget: str = "$$"
    max_walk_min: int = 20

# ----------------------
# 간단 추천 로직
# ----------------------

def score_poi(poi: Dict[str, Any], pref: UserPref) -> float:
    if poi["city"].lower() != pref.city.lower():
        return -1
    if poi["walk_min"] > pref.max_walk_min:
        return -0.5
    # 관심사 겹침 가점
    overlap = len(set(poi["tags"]) & set([t.strip() for t in pref.interests]))
    score = overlap * 2.0
    # 가족여행 가점
    if pref.with_kids and ("가족" in poi["tags"] or "실내" in poi["tags"]):
        score += 1.5
    # 야간/전망 태그는 Night/Evening 우선 배치
    if "야경" in poi["tags"] or "전망" in poi["tags"]:
        score += 0.8
    return score


def plan_itinerary(pref: UserPref) -> Dict[str, Any]:
    # 후보 POI 랭킹
    ranked = sorted(POIS, key=lambda p: score_poi(p, pref), reverse=True)
    ranked = [p for p in ranked if score_poi(p, pref) > 0]

    # 일×슬롯 배치
    itinerary = {}
    idx = 0
    for d in range(1, pref.days + 1):
        day_plan = []
        for slot in SLOTS:
            if idx < len(ranked):
                poi = ranked[idx]
                # 야경/전망은 Night/Dinner에 배치되도록 간단 스왑
                if ("야경" in poi["tags"] or "전망" in poi["tags"]) and slot not in ["Dinner","Night"]:
                    # 다음 후보로 넘기고 뒤 슬롯에서 소화
                    idx += 1
                    continue
                day_plan.append({
                    "slot": slot,
                    "name": poi["name"],
                    "tags": poi["tags"],
                    "eta_min": poi["avg_stay"],
                    "walk_min": poi["walk_min"],
                    "price": poi["price"],
                    "notes": poi.get("notes","")
                })
                idx += 1
        itinerary[f"Day {d}"] = day_plan

    return {
        "city": pref.city,
        "days": pref.days,
        "itinerary": itinerary,
    }

# ----------------------
# (선택) LLM 리라이트 – 설명/가이드 문장화
# ----------------------

def llm_rewrite(pref: UserPref, plan: Dict[str, Any]) -> str:
    if not USE_LLM:
        # LLM 사용 불가 시 간단 요약 문자열 생성
        return (
            f"{pref.city.title()} {pref.days}일 일정 초안입니다. 관심사: {', '.join(pref.interests)}. "
            f"도보제약 {pref.max_walk_min}분, 가족동반: {pref.with_kids}. 각 Day별 슬롯에 맞춰 추천을 배치했어요."
        )

    # OpenAI Responses (GPT 계열) – 모델명은 환경에 맞게 조정
    content = {
        "role": "system",
        "content": (
            "당신은 현실적인 여행 플래너입니다. 추정은 금지하고, 각 선택의 근거를 짧게 덧붙이세요. "
            "출력은 1)요약, 2)일정표(슬롯/장소/이동/체류시간), 3)주의사항 순서로 한국어로 작성."
        ),
    }
    user = {
        "role": "user",
        "content": json.dumps({"pref": asdict(pref), "plan": plan}, ensure_ascii=False)
    }
    resp = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[content, user],
        temperature=0.4,
    )
    return resp.choices[0].message.content

# ----------------------
# API
# ----------------------

@app.route("/health", methods=["GET"])
def health():
    return {"ok": True, "llm": USE_LLM}


@app.route("/plan", methods=["POST"])
def plan():
    data = request.get_json(force=True)
    pref = UserPref(
        city=data.get("city","osaka"),
        days=int(data.get("days",2)),
        interests=data.get("interests", ["먹거리","야경"]),
        with_kids=bool(data.get("with_kids", False)),
        budget=data.get("budget","$$"),
        max_walk_min=int(data.get("max_walk_min", 20)),
    )

    draft = plan_itinerary(pref)
    narrative = llm_rewrite(pref, draft)

    return jsonify({
        "pref": asdict(pref),
        "draft": draft,
        "narrative": narrative,
    })


if __name__ == "__main__":
    # 실행:  python travelbot_mvp_app.py
    app.run(host="0.0.0.0", port=8000, debug=True)
