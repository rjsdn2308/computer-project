# Fruit Vision App 🍎
TensorFlow + Flutter 기반 유아용 과일 학습 앱

## 실행 방법
1️⃣ `model_training/train_model_tf.py` 실행 → 모델 학습 및 `fruit_model_quant.tflite` 생성  
2️⃣ 생성된 TFLite 모델을 `flutter_app/assets/model/` 에 복사  
3️⃣ Flutter 실행  
```bash
cd flutter_app
flutter pub get
flutter run