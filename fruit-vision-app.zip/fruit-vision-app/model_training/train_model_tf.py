import tensorflow as tf
from tensorflow.keras import layers, models, callbacks
import os

IMG_SIZE = (224, 224)
BATCH_SIZE = 32
DATA_DIR = "dataset/"
MODEL_DIR = "../trained_model"
os.makedirs(MODEL_DIR, exist_ok=True)

# 데이터셋 불러오기
train_ds = tf.keras.preprocessing.image_dataset_from_directory(
    DATA_DIR,
    validation_split=0.2,
    subset="training",
    seed=42,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
)
val_ds = tf.keras.preprocessing.image_dataset_from_directory(
    DATA_DIR,
    validation_split=0.2,
    subset="validation",
    seed=42,
    image_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
)

AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.prefetch(AUTOTUNE)
val_ds = val_ds.prefetch(AUTOTUNE)

# 데이터 증강
data_augmentation = tf.keras.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.1),
    layers.RandomZoom(0.2),
    layers.RandomContrast(0.1),
])

# EfficientNetV2 전이학습
base = tf.keras.applications.EfficientNetV2S(
    include_top=False, input_shape=IMG_SIZE+(3,), weights="imagenet"
)
base.trainable = False

inputs = tf.keras.Input(shape=IMG_SIZE+(3,))
x = data_augmentation(inputs)
x = tf.keras.applications.efficientnet_v2.preprocess_input(x)
x = base(x, training=False)
x = layers.GlobalAveragePooling2D()(x)
x = layers.Dropout(0.3)(x)
outputs = layers.Dense(len(train_ds.class_names), activation="softmax")(x)
model = models.Model(inputs, outputs)

model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])

# 콜백
early = callbacks.EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True)
ckpt = callbacks.ModelCheckpoint("../trained_model/fruit_model_best.h5", save_best_only=True)

# 학습
history = model.fit(train_ds, validation_data=val_ds, epochs=10, callbacks=[early, ckpt])

# TFLite 변환
converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]
tflite_model = converter.convert()
open("../trained_model/fruit_model_quant.tflite", "wb").write(tflite_model)

print("✅ 학습 완료 및 TFLite 변환 성공!")
