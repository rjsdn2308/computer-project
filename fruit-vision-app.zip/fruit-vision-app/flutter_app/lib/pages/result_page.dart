import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

class ResultPage extends StatefulWidget {
  final Map<String, dynamic> result;
  final File image;
  const ResultPage({super.key, required this.result, required this.image});
  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  final FlutterTts tts = FlutterTts();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("결과")),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.file(widget.image, height: 200),
          const SizedBox(height: 20),
          Text("${widget.result['fruit']}는 ${widget.result['growth']}에서 자라요!",
              style: const TextStyle(fontSize: 22)),
          ElevatedButton(
            onPressed: () =>
              tts.speak("${widget.result['fruit']}는 ${widget.result['growth']}에서 자라요"),
            child: const Text("들어보기 🔊"),
          ),
        ],
      ),
    );
  }
}
