import 'dart:io';
import 'package:image/image.dart' as img;
import 'package:tflite_flutter/tflite_flutter.dart';
import '../utils/label_map.dart';

class TFLiteService {
  late Interpreter _interpreter;
  TFLiteService() {
    _interpreter = Interpreter.fromAsset('assets/model/fruit_model.tflite');
  }

  Future<Map<String, dynamic>> runModel(File image) async {
    var bytes = await image.readAsBytes();
    var decoded = img.decodeImage(bytes)!;
    var resized = img.copyResize(decoded, width: 224, height: 224);
    var input = List.generate(1, (_) => List.generate(224, (_) =>
      List.generate(224, (_) => List.filled(3, 0.0))));
    for (int y=0; y<224; y++)
      for (int x=0; x<224; x++) {
        var p = resized.getPixel(x, y);
        input[0][y][x][0] = img.getRed(p)/255.0;
        input[0][y][x][1] = img.getGreen(p)/255.0;
        input[0][y][x][2] = img.getBlue(p)/255.0;
      }
    var output = List.filled(labelMap.length, 0.0).reshape([1, labelMap.length]);
    _interpreter.run(input, output);
    var idx = output[0].indexOf(output[0].reduce((a,b)=>a>b?a:b));
    var fruit = labelMap.keys.elementAt(idx);
    var growth = labelMap[fruit];
    return {'fruit': fruit, 'growth': growth};
  }
}
