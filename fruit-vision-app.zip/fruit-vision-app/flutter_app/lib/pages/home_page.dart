import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/tflite_service.dart';
import 'result_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final picker = ImagePicker();
  File? _image;
  final _service = TFLiteService();

  Future<void> _pickAndPredict() async {
    final picked = await picker.pickImage(source: ImageSource.camera);
    if (picked == null) return;
    setState(() => _image = File(picked.path));
    final result = await _service.runModel(_image!);
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) =>
      ResultPage(result: result, image: _image!)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("어디에서 자라나요?")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text("과일을 찍어보세요 🍎", style: TextStyle(fontSize: 20)),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: _pickAndPredict, child: const Text("사진 찍기")),
          ],
        ),
      ),
    );
  }
}
