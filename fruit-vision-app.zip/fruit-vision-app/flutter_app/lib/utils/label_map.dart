const Map<String, String> labelMap = {
  "apple": "나무",
  "peanut": "땅속"
};
